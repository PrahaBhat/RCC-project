# This will process the results obtained from HPC for further analysis
library(hrbrthemes)
library(tidyverse)
library(readxl)
library(viridis)

# Function to remove outliers using IQR
remove_outliers <- function(column) {
  q1 <- quantile(column, 0.25, na.rm = TRUE)
  q3 <- quantile(column, 0.75, na.rm = TRUE)
  iqr <- q3 - q1
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  
  column[column < lower_bound | column > upper_bound] <- NA
  return(column)
}

mets_folder <- "~/Data/MDACC/Collaborations/Kanishka/ccRCC-Metastasis/HPC_simulation_results/mets/"

# Get the simulation results data
files <- list.files(path=mets_folder, pattern="*.RDS", full.names=TRUE, recursive=FALSE)

# Make a list and vectors
my_mets_list <- list()
vec_GC <- c()
vec_GR <- c()
vec_IC <- c()
vec_IR <- c()
file_name <- c()

for (i in files) {
  
  sim_result <- readRDS(i)
  vec_GC <- c(vec_GC, mean(sim_result$Gam_cells))
  vec_GR <- c(vec_GR, mean(sim_result$Gam_random_cells))
  vec_IC <- c(vec_IC, mean(sim_result$Int_cells))
  vec_IR <- c(vec_IR, mean(sim_result$Int_random_cells))
  file_name <- c(file_name, basename(i))
  
}

# Assign the list
my_mets_list$GC <- vec_GC
my_mets_list$GR <- vec_GR
my_mets_list$IC <- vec_IC
my_mets_list$IR <- vec_IR
file_name <- data.frame(file_name)

# Split the column using the first delimiter "|"
df_split <- file_name %>%
  separate(col = file_name, into = c("col1", "col2", "col3"), sep = "\\.") %>% select(col1)
df_split$col1 <- gsub("_", "", df_split$col1)
# Split the column based on the hyphen ("-")
df_split <- as.data.frame(do.call(rbind, strsplit(as.character(df_split$col1), "-")))
colnames(df_split) <- c("col1", "col2", "col3", "col4")
df <- df_split %>%
  mutate(PID = paste(col1, col2, col3, sep = "-"))

# Include patient id and condition to the list
my_mets_list$PID <- df$PID
my_mets_list <- as.data.frame(my_mets_list)

# Group by 'PID' and calculate the mean for each columns
result_mets <- my_mets_list %>%
  group_by(PID) %>%
  summarise(
    Mean_GC = mean(GC),
    Mean_GR = mean(GR),
    Mean_IC = mean(IC),
    Mean_IR = mean(IR)
  )

result_mets$condition <- "mets"
df_mets <- as.data.frame(result_mets)

# This will process the results obtained from HPC for further analysis

no_mets_folder <- "~/Data/MDACC/Collaborations/Kanishka/ccRCC-Metastasis/HPC_simulation_results/no_mets/"

# Get the simulation results data
files <- list.files(path=no_mets_folder, pattern="*.RDS", full.names=TRUE, recursive=FALSE)

# Make a list and vectors
my_no_mets_list <- list()
vec_GC <- c()
vec_GR <- c()
vec_IC <- c()
vec_IR <- c()
file_name <- c()

for (i in files) {
  
  sim_result <- readRDS(i)
  vec_GC <- c(vec_GC, mean(sim_result$Gam_cells))
  vec_GR <- c(vec_GR, mean(sim_result$Gam_random_cells))
  vec_IC <- c(vec_IC, mean(sim_result$Int_cells))
  vec_IR <- c(vec_IR, mean(sim_result$Int_random_cells))
  file_name <- c(file_name, basename(i))
  
}

# Assign the list
my_no_mets_list$GC <- vec_GC
my_no_mets_list$GR <- vec_GR
my_no_mets_list$IC <- vec_IC
my_no_mets_list$IR <- vec_IR
file_name <- data.frame(file_name)

# Split the column using the first delimiter "|"
df_split <- file_name %>%
  separate(col = file_name, into = c("col1", "col2", "col3"), sep = "\\.") %>% select(col1)
df_split$col1 <- gsub("_", "", df_split$col1)
# Split the column based on the hyphen ("-")
df_split <- as.data.frame(do.call(rbind, strsplit(as.character(df_split$col1), "-")))
colnames(df_split) <- c("col1", "col2", "col3", "col4")
df <- df_split %>%
  mutate(PID = paste(col1, col2, col3, sep = "-"))

# Include patient id and condition to the list
my_no_mets_list$PID <- df$PID
my_no_mets_list <- as.data.frame(my_no_mets_list)

# Group by 'PID' and calculate the mean for each columns
result_no_mets <- my_no_mets_list %>%
  group_by(PID) %>%
  summarise(
    Mean_GC = mean(GC),
    Mean_GR = mean(GR),
    Mean_IC = mean(IC),
    Mean_IR = mean(IR)
  )

result_no_mets$condition <- "no_mets"
df_no_mets <- as.data.frame(result_no_mets)

# Combine the df_mets and df_no_mets data frame
df <- rbind(df_mets, df_no_mets)

cluster_ids <- read_excel("~/Data/MDACC/Collaborations/Kanishka/ccRCC-Metastasis/cluster ids.xlsx")
colnames(cluster_ids) <- c('PID', "cluster")

# Inner join and extract the clusters
clusters_df <- inner_join(df, cluster_ids, by = "PID")
cluster_1_mets <- clusters_df %>% filter(cluster == "cluster1") %>% filter(condition == "mets")
cluster_2_no_mets <- clusters_df %>% filter(cluster == "cluster2") %>% filter(condition == "no_mets")

wilcox.test(cluster_2_no_mets$Mean_IC, cluster_2_no_mets$Mean_IR)

clusters_mets_no_mets <- rbind(cluster_1_mets, cluster_2_no_mets)

df_long <- cluster_1_mets %>% gather(key = "variable", value = "value", starts_with("Mean_I"))

df_long %>%
  ggplot( aes(x=variable, y=value, fill=variable)) +
  geom_boxplot() +
  scale_fill_viridis(discrete = TRUE, alpha=0.6, option="A") +
  theme_ipsum() +
  theme(
    legend.position="none",
    plot.title = element_text(size=11)
  ) +
  ggtitle("Cluster1 Mets vs Cluster 2 No Mets") +
  xlab("")


