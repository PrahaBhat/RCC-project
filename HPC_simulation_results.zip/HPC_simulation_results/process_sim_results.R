# This will process the results obtained from HPC for further analysis

# Function to remove outliers using IQR
remove_outliers <- function(column) {
  q1 <- quantile(column, 0.25, na.rm = TRUE)
  q3 <- quantile(column, 0.75, na.rm = TRUE)
  iqr <- q3 - q1
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  
  column[column < lower_bound | column > upper_bound] <- NA
  return(column)
}

mets_folder <- "~/Data/MDACC/Collaborations/Kanishka/ccRCC-Metastasis/HPC_simulation_results/mets/"

# Get the simulation results data
files <- list.files(path=mets_folder, pattern="*.RDS", full.names=TRUE, recursive=FALSE)

median_list <- list()
median_vec_GC <- c()
median_vec_GR <- c()

for (i in files) {
  
  sim_result <- readRDS(i)
  median_vec_GC <- c(median_vec_GC, mean(sim_result$Gam_cells))
  median_vec_GR <- c(median_vec_GR, mean(sim_result$Gam_random_cells))
  
}

median_list$GC_Mets <- median_vec_GC
median_list$GR_Mets <- median_vec_GR

# This will process the results obtained from HPC for further analysis

mets_folder <- "~/Data/MDACC/Collaborations/Kanishka/ccRCC-Metastasis/HPC_simulation_results/no_mets/"

# Get the simulation results data
files <- list.files(path=mets_folder, pattern="*.RDS", full.names=TRUE, recursive=FALSE)

median_vec_GC <- c()
median_vec_GR <- c()

for (i in files) {
  
  sim_result <- readRDS(i)
  median_vec_GC <- c(median_vec_GC, mean(sim_result$Gam_cells))
  median_vec_GR <- c(median_vec_GR, mean(sim_result$Gam_random_cells))
  
}

median_list$GC_No_Mets <- median_vec_GC
median_list$GR_No_Mets <- median_vec_GR

# Find the maximum length of vectors in the list
max_length <- max(sapply(median_list, length))

# Pad shorter vectors with NA and create the transposed data frame
my_data_frame <- data.frame(t(do.call(rbind, lapply(median_list, function(x) c(x, rep(NA, max_length - length(x)))))))

# Apply the function to each column in the data frame
# df_cleaned <- apply(my_data_frame, 2, remove_outliers)
# df_cleaned <- data.frame(df_cleaned)

# my_data_frame <- df_cleaned

# my_data_frame <- as.data.frame(scale(my_data_frame))

df_long <- my_data_frame %>% gather(key = "variable", value = "value", starts_with("G"))
df_long <- na.omit(df_long)

# Plot
df_long %>%
  ggplot( aes(x=variable, y=value, fill=variable)) +
  geom_boxplot() +
  scale_fill_viridis(discrete = TRUE, alpha=0.6) +
  geom_jitter(color="black", size=0.4, alpha=0.9) +
  theme_ipsum() +
  theme(
    legend.position="none",
    plot.title = element_text(size=11)
  ) +
  ggtitle("A boxplot with jitter") +
  xlab("")

# Create a scatter plot
scatter_plot <- ggplot(my_data_frame, aes(x = GC_Mets, y = GR_Mets)) +
  geom_point(color = "blue") +  # Scatter plot for the first and second columns
  geom_point(aes(x = GC_No_Mets, y = GR_No_Mets), color = "red") +  # Scatter plot for the third and fourth columns
  labs(x = "X-axis Label", y = "Y-axis Label", title = "Scatter Plot")

# Print the scatter plot
print(scatter_plot)

# Without transparency (left)
p1 <- ggplot(data=df_long, aes(x=value, group=variable, fill=variable)) +
  geom_density(adjust=1.5) +
  theme_ipsum()

print(p1)
